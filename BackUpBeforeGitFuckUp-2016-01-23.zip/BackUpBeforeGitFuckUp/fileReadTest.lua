function fileExists(filename)
     file = io.open(filename, "r")
     if file == nil then
          return false
     else
          file.close(file)
          return true
         end
   end

  if fileExists ("messageFile.txt") then
            lines = {}
            for line in io.lines(file) do
            lines[#lines + 1] = line
            end
            print(lines[1])
            end
            
  else
            print("not found")
  end


print('stop')
io.read()