#This script opens a text file where the code for the lua script is stored and edits the lines containing the strings that the user wants to print.
#Once the strings have been replaced, it saves the file as a .lua file for the user to upload to the MYO Application Manager

import os

thisFile = "messageList1.lua"
base = os.path.splitext(thisFile)[0]
os.rename(thisFile, base + ".txt")

# with is like your try .. finally block in this case
with open('messageList1.txt', 'r') as file:
    # read a list of lines into data
    data = file.readlines()

print data

# now change the 2nd line, note that you have to add a newline
data[67] = 'waveInGestureString = "changed wave in gesture"\n'
data[68] = 'waveOutGestureString = "changed wave out gesture"\n'
data[69] = 'fistGesture = "fist gesture"\n'
data[70] = 'openHandGesture = "open hand gesture"\n'

# and write everything back
with open('messageList1.txt', 'w') as file:
    file.writelines( data )      

thisFile = "messageList1.txt"
base = os.path.splitext(thisFile)[0]
os.rename(thisFile, base + ".lua")
 

