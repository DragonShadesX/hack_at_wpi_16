-- Opens a file in read
file = io.open("canned_responses.txt", "r")
print("opened file")

-- sets the default input file as test.lua
io.input(file)
print("input file type set")

-- prints the first line of the file
print(io.read())
print("that was the first line of the file")

-- closes the open file
io.close(file)
print("close file")